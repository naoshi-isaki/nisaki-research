---
title: /Yascha-Mounk
published: 2025-05-01
updated: 2025-05-01T19:39:25+09:00
url: https://nisaki.hatenablog.jp/entry/2025/05/01/193925
entry-id: tag:blog.hatena.ne.jp,2013:blog-Nisaki-6801883189054638642-6802418398398624539
author: Nisaki
edited: 2025-05-01T19:39:25+09:00
draft: true---

<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Fcourrier.jp%2Fnews%2Farchives%2F399153%2F" title="政治学者ヤシャ・モンク「世界幸福度ランキングは、ただのインチキだ」 | 別調査で日本や米国は「北欧諸国より幸福」" class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://courrier.jp/news/archives/399153/">courrier.jp</a></cite></p>
<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Fyaschamounk.substack.com%2Fp%2Fthe-world-happiness-report-is-a-sham" title="The World Happiness Report Is a Sham" class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://yaschamounk.substack.com/p/the-world-happiness-report-is-a-sham">yaschamounk.substack.com</a></cite></p>
