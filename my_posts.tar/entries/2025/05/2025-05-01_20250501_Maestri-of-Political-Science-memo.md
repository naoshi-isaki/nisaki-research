---
title: 20250501/Maestri-of-Political-Science-memo
published: 2025-05-01
updated: 2025-05-01T18:01:47+09:00
url: https://nisaki.hatenablog.jp/entry/2025/05/01/180147
entry-id: tag:blog.hatena.ne.jp,2013:blog-Nisaki-6801883189054638642-6802418398398302222
author: Nisaki
edited: 2025-05-01T18:02:16+09:00---

<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Fecpr.eu%2FShop%2FShopProductInfo%3FproductID%3D14" title="Masters of Political Science" class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://ecpr.eu/Shop/ShopProductInfo?productID=14">ecpr.eu</a></cite></p>
<p>Robert Dahl, Anthony Downs, David Easton, S. E. Finer, Samuel P. Huntington, Juan J. Linz, Seymour Martin Lipset, Giovanni Sartori, Sidney Verba, Aaron Wildavsky,Hans Morgenthau.</p>
<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Fwww.akademibokhandeln.se%2Fbok%2Fmaestri-of-political-science%2F9781907301193%3Fsrsltid%3DAfmBOoos_rMQKXjYm2vd7oHE1HYiUZOHS1JxwMvvpUSUg5zsyYsp0SbD" title="Maestri of Political Science: 2" class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><a href="https://ecpr.eu/Shop/ShopProductInfo?productID=14"> </a><a href="https://www.akademibokhandeln.se/bok/maestri-of-political-science/9781907301193?srsltid=AfmBOoos_rMQKXjYm2vd7oHE1HYiUZOHS1JxwMvvpUSUg5zsyYsp0SbD">www.akademibokhandeln.se</a></p>
<p>Gabriel A. Almond, Raymond Aron, Philip Converse, Maurice Duverger, Stanley Hoffmann, Paul Lazarsfeld, Arend Lijphart, Elinor Ostrom, William H. Riker, Stein Rokkan and Susan Strange.</p>
<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Fecpr.eu%2FShop%2FShopProductInfo%3FproductID%3D197" title="Maestri of Political Science: Volume 3" class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe></p>
<p><cite class="hatena-citation"><a href="https://ecpr.eu/Shop/ShopProductInfo?productID=197">ecpr.eu</a></cite></p>
<p>Hannah Arendt, Karl Deutsch, Carl Friedrich, Jane Mansbridge, C. Wright Mills, Guillermo O’Donnell, Carole Pateman, Adam Przeworski, Robert Putnam and Kenneth Waltz.</p>
<p> </p>
<p> </p>
