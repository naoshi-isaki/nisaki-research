---
title: /Reform-UK-result
published: 2025-05-12
updated: 2025-05-12T03:25:08+09:00
url: https://nisaki.hatenablog.jp/entry/2025/05/12/032508
entry-id: tag:blog.hatena.ne.jp,2013:blog-Nisaki-6801883189054638642-6802418398424407115
author: Nisaki
edited: 2025-05-12T03:25:08+09:00
draft: true---

<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Fwww.jetro.go.jp%2Fbiznews%2F2025%2F05%2F11f98f70fcf58240.html" title="地方議会選で右派・リフォームUKが躍進、2大政党は議席大幅減(英国) | ビジネス短信 ―ジェトロの海外ニュース" class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://www.jetro.go.jp/biznews/2025/05/11f98f70fcf58240.html">www.jetro.go.jp</a></cite></p>
