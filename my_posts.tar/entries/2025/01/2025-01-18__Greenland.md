---
title: /Greenland
published: 2025-01-18
updated: 2025-01-18T01:43:13+09:00
url: https://nisaki.hatenablog.jp/entry/2025/01/18/014313
entry-id: tag:blog.hatena.ne.jp,2013:blog-Nisaki-6801883189054638642-6802418398320968655
author: Nisaki
edited: 2025-01-18T01:43:13+09:00
draft: true---

<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Fwww.politico.com%2Fnews%2Fmagazine%2F2025%2F01%2F16%2Fspiritual-case-greenland-trump-00198848" title="The Spiritual Case for Greenland" class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://www.politico.com/news/magazine/2025/01/16/spiritual-case-greenland-trump-00198848">www.politico.com</a></cite></p>
<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Fgoodauthority.org%2Fnews%2Ftrump-just-said-buying-greenland-would-be-a-large-real-estate-deal-hes-making-a-dangerous-mistake%2F" title="Why Trump can't buy Greenland." class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://goodauthority.org/news/trump-just-said-buying-greenland-would-be-a-large-real-estate-deal-hes-making-a-dangerous-mistake/">goodauthority.org</a></cite></p>
