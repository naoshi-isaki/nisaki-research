---
title: 20251003/Tribute-Offe-Ruesmeier
published: 2025-10-05
updated: 2025-10-05T23:12:26+09:00
url: https://nisaki.hatenablog.jp/entry/2025/10/05/231226
entry-id: tag:blog.hatena.ne.jp,2013:blog-Nisaki-6801883189054638642-6802888565276017137
author: Nisaki
edited: 2025-10-05T23:12:55+09:00---

<blockquote class="twitter-tweet" data-conversation="none" data-lang="ja">
<p dir="ltr" lang="en">Claus Offe<br /><br />These are some works that will give you a sense of what kind of a thinker Offe was.<br /><br />Contradictions of the Welfare State: <a href="https://t.co/9SOiyVZtC0">https://t.co/9SOiyVZtC0</a><br /><br />Two Logics: <a href="https://t.co/Lo8hdru7vt">https://t.co/Lo8hdru7vt</a><br /><br />New Social Movements: <a href="https://t.co/ZZWk7bTPAj">https://t.co/ZZWk7bTPAj</a> <a href="https://t.co/EQjyKpc7uj">https://t.co/EQjyKpc7uj</a> <a href="https://t.co/x27YLbGMz6">pic.twitter.com/x27YLbGMz6</a></p>
— Gerardo L. Munck (@GerardoMunck) <a href="https://twitter.com/GerardoMunck/status/1974153970030686240?ref_src=twsrc%5Etfw">2025年10月3日</a></blockquote>
<p>
<script async="" src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
</p>
<p>
<script async="" src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
</p>
<blockquote class="twitter-tweet" data-conversation="none" data-lang="ja">
<p dir="ltr" lang="en">RIP Claus Offe, the author of all below, but for me especially scholar who highligted the difficulty of simultanous democratization, economic transition and state-building after communism in Institutional Design in Post-Communist Societies: Rebuilding the Ship at Sea <a href="https://t.co/2vBzP8SU9i">https://t.co/2vBzP8SU9i</a></p>
— Petra Guasti (@PetraGuasti) <a href="https://twitter.com/PetraGuasti/status/1974108984576782540?ref_src=twsrc%5Etfw">2025年10月3日</a></blockquote>
<p>
<script async="" src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
</p>
<blockquote class="twitter-tweet" data-conversation="none" data-lang="ja">
<p dir="ltr" lang="en">sad news: vale my friend and colleague Claus Offe (1940 - 2025), among the finest political sociologists of our generation, who generously trusted me to translate and edit his early work… <a href="https://t.co/z2Cvd9b8ML">pic.twitter.com/z2Cvd9b8ML</a></p>
— John Keane (@jkeaneSDN) <a href="https://twitter.com/jkeaneSDN/status/1974091159116095921?ref_src=twsrc%5Etfw">2025年10月3日</a></blockquote>
<p>
<script async="" src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
</p>
<blockquote class="bluesky-embed" data-bluesky-uri="at://did:plc:sdb5vx3ua5z2fnrvijpkvtwm/app.bsky.feed.post/3m27vf4eghs2h" data-bluesky-cid="bafyreieciuqhfsdhdbwi6lqlxxbakgbtbccqmrrwxougbt6qwglu6asiwa">
<p lang="en">A giant of social science -- und ein wunderbarer Mensch. He will be much missed.</p>
— <a href="https://bsky.app/profile/did:plc:sdb5vx3ua5z2fnrvijpkvtwm?ref_src=embed">Jan-Werner Mueller (@jwmueller-pu.bsky.social)</a> <a href="https://bsky.app/profile/did:plc:sdb5vx3ua5z2fnrvijpkvtwm/post/3m27vf4eghs2h?ref_src=embed">2025-10-02T15:42:45.700Z</a></blockquote>
<p>
<script async="" src="https://embed.bsky.app/static/embed.js" charset="utf-8"></script>
<cite class="hatena-citation"><a href="https://bsky.app/profile/jwmueller-pu.bsky.social/post/3m27vf4eghs2h">bsky.app</a></cite></p>
<p>---</p>
<blockquote class="twitter-tweet" data-conversation="none" data-lang="ja">
<p dir="ltr" lang="en">Dietrich Rueschemeyer<br /><br />German-American sociologist Dietrich Rueschemeyer passed away a few days ago.<br /><br />He was a social theorist and macro-sociologist who contributed to knowledge about the state, democracy, and comparative historical sociology.<br /><br />These are some of his main works.👇 <a href="https://t.co/RYxxswnuFm">pic.twitter.com/RYxxswnuFm</a></p>
— Gerardo L. Munck (@GerardoMunck) <a href="https://twitter.com/GerardoMunck/status/1974066901543497826?ref_src=twsrc%5Etfw">2025年10月3日</a></blockquote>
<p>
<script async="" src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
</p>
<p> </p>
