---
title: /van-Kessel-and-Zaslove
published: 2025-10-01
updated: 2025-10-01T15:45:10+09:00
url: https://nisaki.hatenablog.jp/entry/2025/10/01/154510
entry-id: tag:blog.hatena.ne.jp,2013:blog-Nisaki-6801883189054638642-6802888565266362014
author: Nisaki
edited: 2025-10-01T15:45:10+09:00
draft: true---

<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Fwww.illiberalism.org%2Fwhat-mainstream-parties-and-media-should-learn-from-the-dutch-extreme-right-riots%2F" title="What Mainstream Parties and Media Should Learn from the Dutch Extreme-Right Riots illiberalism.org |" class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://www.illiberalism.org/what-mainstream-parties-and-media-should-learn-from-the-dutch-extreme-right-riots/">www.illiberalism.org</a></cite></p>
