---
title: 20241126/geography-RRvoting
published: 2024-11-07
updated: 2024-11-27T00:00:00+09:00
url: https://nisaki.hatenablog.jp/entry/2024/12/07/111736
entry-id: tag:blog.hatena.ne.jp,2013:blog-Nisaki-6801883189054638642-6802418398302095954
author: Nisaki
edited: 2024-12-07T11:17:36+09:00
draft: true
tags:
  - political_party
  - grancing_abstracts
---

<p>Crulli, M. (2024). Thin or thick? Populist and radical right politics across European cities, suburbs, and countryside. Comparative European Politics, 22(6), 792-838.<br />https://doi.org/10.1057/s41295-024-00382-8</p>
<blockquote>
<p>ポピュリストや急進右派の急増は、ヨーロッパの政治地理を再形成した。しかし、居住地とポピュリズムや急進右派の政治との関連は、最近まで軽視されがちであった。本稿では、現代ヨーロッパにおけるポピュリズムや急進右派への支持と居住地がどのように関連しているかを探ることで、このギャップを解消する。「都市」、「町-郊外」、「田舎」の区別に焦点を当て、異なる居住環境におけるポピュリズムと急進右派の投票と態度について、個人レベルでの調査を行った。分析は、西ヨーロッパ（WE）と中東ヨーロッパ（CEE）の23カ国の欧州社会調査（2020-22年）のデータに基づいている。重要な発見は、都市と郊外・農村部のクリーヴィッジは、急進右派のイデオロギー的基盤である権威主義や排外主義と、純粋なポピュリズムという薄い次元よりも、はるかに関係が深いということである。個人の社会経済的プロフィール、政治的志向、地域がどの程度取り残されているか、WEとCEEのどちらに住んでいるかに関係なく、居住地が田舎であればあるほど、排外主義は特に強くなる。したがって、政治の地理的分極化に関する今後の研究は、ポピュリズムそのものよりも、急進右派に目を向けるべきかもしれない。</p>
</blockquote>
<p> </p>
