---
title: 20241102/status-anxiety_RRvoting
published: 2024-11-02
updated: 2024-11-02T12:06:55+09:00
url: https://nisaki.hatenablog.jp/entry/2024/11/02/120655
entry-id: tag:blog.hatena.ne.jp,2013:blog-Nisaki-6801883189054638642-6802418398300814733
author: Nisaki
edited: 2024-11-05T11:40:59+09:00---

<blockquote class="bluesky-embed" data-bluesky-uri="at://did:plc:xqroftjlkjq74wa6x4bqw6gf/app.bsky.feed.post/3l7gf4pa3xm2b" data-bluesky-cid="bafyreigcjaoazarfggihwx3hv4nvpz67kiwkzkkxgdetls3yicylvtw6q4">
<p lang="en">Seymour Martin Lipset was a true visionary. Already in the 1950s, he explained support for the radical right through “status anxiety”. www.nytimes.com/interactive/...</p>
— <a href="https://bsky.app/profile/did:plc:xqroftjlkjq74wa6x4bqw6gf?ref_src=embed">Cas Mudde (@casmudde.bsky.social)</a> <a href="https://bsky.app/profile/did:plc:xqroftjlkjq74wa6x4bqw6gf/post/3l7gf4pa3xm2b?ref_src=embed">2024-10-26T15:20:07.765Z</a></blockquote>
<p>
<script async="" src="https://embed.bsky.app/static/embed.js" charset="utf-8"></script>
<cite class="hatena-citation"><a href="https://bsky.app/profile/casmudde.bsky.social/post/3l7gf4pa3xm2b">bsky.app</a></cite></p>
<blockquote>
<p>Seymour Martin Lipset was a true visionary. Already in the 1950s, he explained support for the radical right through “status anxiety”.</p>
<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Fwww.nytimes.com%2Finteractive%2F2024%2F10%2F26%2Fupshot%2Fcensus-relative-income.html%3Fsmid%3Dnytcore-ios-share%26referringSource%3DarticleShare" title="They Used to Be Ahead in the American Economy. Now They’ve Fallen Behind." class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://www.nytimes.com/interactive/2024/10/26/upshot/census-relative-income.html?smid=nytcore-ios-share&amp;referringSource=articleShare">www.nytimes.com</a></cite></p>
<p><img src="https://static01.nyt.com/images/2024/10/24/multimedia/2024-08-26-job-standings-lookup-index/2024-08-26-job-standings-lookup-index-videoSixteenByNine3000-v3.png" alt="They Used to Be Ahead in the American Economy. Now They've Fallen Behind. -  The New York Times" /></p>
<p>Please keep that in mind when you see contemporary studies use this explanation without citing Lipset. ❌</p>
<p>All of this does not take away from the fact that the decrease in income from (white) workers is criminal! It should be a much bigger priority for Democrats.</p>
<p>That being said, this absolute and relative decline obviously is (1) mainly due to the Republicans and (2) no justification for supporting racism.</p>
</blockquote>
<p>Gidron, N., &amp; Hall, P. A. (2017). The politics of social status: Economic and cultural roots of the populist right. The British journal of sociology, 68, S57-S84.<br />https://doi.org/10.1111/1468-4446.12319</p>
<blockquote>
<p>本稿では、先進民主主義諸国において、特に労働者階級の中心的な男性の間で、最近ポピュリズム右派の候補者や大義に対する支持が高まっている要因を探る。 主要な原因要因が経済的なものなのか文化的なものなのかが議論されるなか、ポピュリズムへの支持を生み出すために経済と文化の発展がどのように相互作用しているのかを理解することが、効果的な分析につながると主張する。 そのための一つの方法として、身分不安はポピュリズム支持を誘発する近接要因であり、経済的・文化的発展はそのような不安を誘発する複合要因であるとみなすことを提案する。 先進民主主義20カ国の国家横断的な調査データを用いて、このアプローチの実行可能性を評価する。 主観的社会的地位の低さが右派ポピュリズム政党支持と関連することを示し、大学教育を受けなかった男性の社会的地位を低下させたと思われる一連の経済的・文化的発展を特定し、そうした男性の相対的社会的地位が先進民主主義国の多くで1987年以降低下していることを示す。 地位効果は、経済的・文化的発展が組み合わさってポピュリスト右派への支持を増加させる一つの経路を提供していると結論づける。</p>
</blockquote>
<p>Gidron, N., &amp; Hall, P. A. (2020). Populism as a Problem of Social Integration. Comparative Political Studies, 53(7), 1027-1059.<br />https://doi.org/10.1177/0010414019879947</p>
<blockquote>
<p>急進的な右派・左派政党への支持は、社会的統合の問題として理解することが有益であり、ポピュリズムの経済的・文化的説明を統合するアプローチであると主張する。 比較調査データを用いて、急進的な右派・左派政党への支持が社会的疎外感と関連しているかどうかを評価する。 規範的秩序への強い愛着、社会的関与、社会的尊敬の感覚を欠いているため、社会的疎外感をより強く感じている人ほど、主流政治から疎外され、急進的な政党を支持する傾向が強いことがわかった。 また、社会的地位に影響を与えるとよく言われる最近の経済的・文化的発展に関する指標と、社会的疎外感との間に、特に低所得者や教育水準の低い人々の間で関連性があることもわかった。 我々は、社会的統合と主観的社会的地位の問題は、比較政治行動学の研究者がもっと注意を払うに値すると結論づけている。</p>
</blockquote>
<ul>
<li>
<blockquote>
<p>Individuals who feel socially marginal may be drawn to parties of the radical right for more complex psychological reasons as well. There is evidence that people who are on the lower rungs of the social ladder are susceptible to a “fear of falling” even farther down it. This leads them to draw sharp social boundaries between “respectable” people like themselves and others to whom less social standing can be ascribed, and immigrants are prime targets for such boundary work (Ehrenreich, 1990; Kefalas, 2003; Kuziemko, Buell, Reich, &amp; Norton, 2014; Peugny, 2009). Thus, low levels of subjective social status may be conducive to the anti-immigrant attitudes on which the radical right bases much of its appeal (Ivarsflaten, 2008). In pioneering studies, Lipset (1955, 1959) found that status anxiety promotes support for the radical right, and recent research in psychology confirms that people who believe their social status is threatened are likely to develop hostility to out-groups, such as immigrants, especially if they can be associated with the status threat (Küpper, Wolf, &amp; Zick, 2010; Riek, Mania, &amp; Gaertner, 2006; Tajfel &amp; Turner, 1979).</p>
</blockquote>
</li>
</ul>
<p>Veit, S., Hirsch, M., Giebler, H., Gründl, J., &amp; Schürmann, B. (2024). Submission or Rebellion? Disentangling the Relationships of Anxiety, Attitudes Toward Authorities, and Right-Wing Populist Party Support. American Behavioral Scientist, 0(0). https://doi.org/10.1177/00027642241240717</p>
<blockquote>
<p>右派ポピュリスト政党（RPP）の成功は、社会的危機とそれに対応する不安を利用した恐怖のレトリックの展開に起因することが多い。 しかし、不安とRPP支持（RPP support）の関係に関する実証的証拠はまだ結論が出ていない。 われわれは、右翼権威主義（RWA）とポピュリスト的態度は、権威に対する相反する見解を意味していると主張する。 ポピュリスト的態度の下位次元である反エリート主義は、既成の権威に対する反抗を意味するが、RWA的服従は権威に従順である。 これらの矛盾した態度が、混合した結果の原因かもしれない。 不安との関係では、反抗も服従も防衛的反応として考えられているが、それらが引き起こす権威に対する反応は相反するものであるため、RPP支持との関係は異なっている。 さらに、経験的研究ではしばしば混同されるRPP支持の源泉としての不安の2つの形態を区別する。具体的な脅威に反応して生じる状況的不安と、拡散的不安または一般的な不安感である。 我々は、調査実験を含む大規模調査データを用いて、不安が権威に対する態度を介してドイツの右派ポピュリスト政党「ドイツのための選択肢」（Alternative für Deutschland、AfD）への支持をどのように促進するかを検証する。 パス分析の結果、我々の仮説が支持され、反エリート主義が不安とAfDへの有権者の支持の正の関係を媒介することが明らかになった。 同時に、権威主義的服従は不安とともに増加するが、反エリート主義とは異なり、AfD支持とは負の関係にある。 さらに、状況的不安と拡散的不安の2つの経路が確認され、権威主義的服従と反エリート主義の相対的重要性は不安の形態によって異なる。</p>
</blockquote>
<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Fwww.taylorfrancis.com%2Fbooks%2Fedit%2F10.4324%2F9781003042433%2Fpsychology-political-polarization-jan-willem-van-prooijen" title="The Psychology of Political Polarization | Jan-Willem van Prooijen | T" class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://www.taylorfrancis.com/books/edit/10.4324/9781003042433/psychology-political-polarization-jan-willem-van-prooijen">www.taylorfrancis.com</a></cite></p>
<ul>
<li>Jetten, J., &amp; Mols, F. (2021). Support for populist parties: Economic deprivation, cultural backlash, or status anxiety?. In The psychology of political polarization (pp. 97-111). Routledge.</li>
</ul>
<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Fblogs.lse.ac.uk%2Fusappblog%2F2021%2F05%2F07%2Fin-explaining-the-rise-of-populism-its-not-economic-anxiety-vs-identity-politics-its-both%2F" title="In explaining the rise of populism, it’s not economic anxiety vs. identity politics – it’s both." class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://blogs.lse.ac.uk/usappblog/2021/05/07/in-explaining-the-rise-of-populism-its-not-economic-anxiety-vs-identity-politics-its-both/">blogs.lse.ac.uk</a></cite></p>
<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Ftheloop.ecpr.eu%2Fthe-anxious-voter-linking-fears-to-right-wing-populist-voting%2F" title="🔮 The anxious voter: linking fears to right-wing populist voting" class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://theloop.ecpr.eu/the-anxious-voter-linking-fears-to-right-wing-populist-voting/">theloop.ecpr.eu</a></cite></p>
