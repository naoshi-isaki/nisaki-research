---
title: /central-bank
published: 2024-11-21
updated: 2024-11-21T21:31:23+09:00
url: https://nisaki.hatenablog.jp/entry/2024/11/21/213123
entry-id: tag:blog.hatena.ne.jp,2013:blog-Nisaki-6801883189054638642-6802418398305738867
author: Nisaki
edited: 2024-11-21T21:31:23+09:00
draft: true---

<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Fwww.vox.com%2Fdonald-trump%2F386048%2Ftrump-federal-reserve-powell-interest-rates-congress-inflation" title="Trump says he wants to influence interest rates. Can he?" class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://www.vox.com/donald-trump/386048/trump-federal-reserve-powell-interest-rates-congress-inflation">www.vox.com</a></cite></p>
<p>Gavin, M., &amp; Manger, M. (2023). Populism and De Facto Central Bank Independence. Comparative Political Studies, 56(8), 1189-1223.</p>
<blockquote>
<p>中央銀行の独立性は金融政策決定の中核をなすものであるが、政治的には依然として論争の的となっている。多くの新興市場では、ポピュリスト政権が中央銀行と頻繁に公然と対立している。 多くの新興市場では、ポピュリスト政権が中央銀行と頻繁に対立している。 我々は、危機交渉の文献を参考に、この紛争をモデル化した。 我々のモデルは、ポピュリストの政治家は、名目上独立した中央銀行を、その法的地位を変更することなく屈服させることが多いと予測する。 エビデンスを提供するために、9000以上のアナリストレポートを機械学習を用いて分類し、中央銀行に対する公的圧力に関する新しいデータセットを構築した。 その結果、ポピュリスト（大衆迎合主義者）の政治家は、非ポピュリスト（大衆迎合主義者）よりも、金融市場のチェックが入らない限り、中央銀行に公的圧力をかける可能性が高く、また金利の譲歩を得る可能性も高いことが分かった。 我々の調査結果は、ポピュリストの圧力に直面した場合、デジュールとデファクトの中央銀行の独立性が一致しないことを強調している。</p>
</blockquote>
<p> </p>
