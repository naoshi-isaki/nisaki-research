---
title: 20241105/Green-policy-and-Election-voting/memo
published: 2024-11-05
updated: 2024-11-05T19:05:00+09:00
url: https://nisaki.hatenablog.jp/entry/2024/11/05/190500
entry-id: tag:blog.hatena.ne.jp,2013:blog-Nisaki-6801883189054638642-6802418398301671753
author: Nisaki
edited: 2024-11-05T19:05:00+09:00---

<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Fthreadreaderapp.com%2Fthread%2F1853182240219689061.html" title="Thread by @alexgazmararian on Thread Reader App" class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://threadreaderapp.com/thread/1853182240219689061.html">threadreaderapp.com</a></cite></p>
<blockquote class="twitter-tweet" data-conversation="none" data-lang="ja">
<p dir="ltr" lang="en">This thread only scratches the surface.<br /><br />Climate change isn’t the main issue that affects elections. But this thread shows how the green transition still can affect voting.<br /><br />It's mostly a story of backlash, but that may change with the green industrial policy pivot.</p>
— Alexander F. Gazmararian (@alexgazmararian) <a href="https://twitter.com/alexgazmararian/status/1853182262977937729?ref_src=twsrc%5Etfw">2024年11月3日</a></blockquote>
<p>
<script async="" src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
</p>
<p> </p>
<p>
<script async="" src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
</p>
<p> </p>
