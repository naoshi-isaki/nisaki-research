---
title: /Democratization
published: 2024-10-22
updated: 2024-10-22T00:30:20+09:00
url: https://nisaki.hatenablog.jp/entry/2024/10/22/003020
entry-id: tag:blog.hatena.ne.jp,2013:blog-Nisaki-6801883189054638642-6802418398297928566
author: Nisaki
edited: 2024-10-22T00:30:20+09:00
draft: true---

<p>Democratization, Volume 31, Issue 4 (2024)<br /><a href="https://www.tandfonline.com/toc/fdem20/31/4" target="_blank">https://www.tandfonline.com/toc/fdem20/31/4</a></p>
<p>Ridge, H. M. (2023). The d-word: surveying democracy in America. Democratization, 31(4), 852–870. https://doi.org/10.1080/13510347.2023.2284279</p>
<p>van Lit, J., van Ham, C., &amp; Meijers, M. J. (2023). Countering autocratization: a roadmap for democratic defence. Democratization, 31(4), 765–787. https://doi.org/10.1080/13510347.2023.2279677</p>
<p>DeHanas, D. N. (2023). The spirit of populism: sacred, charismatic, redemptive, and apocalyptic dimensions. Democratization, 31(4), 831–851. https://doi.org/10.1080/13510347.2023.2284277</p>
<p>Werner, A., &amp; Heinisch, R. (2023). Ideological beasts or effective organizations? Do voters’ views of democracy affect their expectations of political parties? Democratization, 31(4), 741–764. https://doi.org/10.1080/13510347.2023.2278709</p>
