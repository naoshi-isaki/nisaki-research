---
title: /democracy
published: 2024-10-30
updated: 2024-10-31T10:06:49+09:00
url: https://nisaki.hatenablog.jp/entry/2024/10/31/100649
entry-id: tag:blog.hatena.ne.jp,2013:blog-Nisaki-6801883189054638642-6802418398300076985
author: Nisaki
edited: 2024-10-31T10:06:49+09:00
draft: true---

<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Fnote.com%2Fshintoyo%2Fn%2Fn0e7550f53299" title="「民主主義（デモクラシー）」の定義について｜shintoyo" class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://note.com/shintoyo/n/n0e7550f53299">note.com</a></cite></p>
<blockquote class="twitter-tweet" data-conversation="none" data-lang="ja">
<p dir="ltr" lang="ja">デモクラシー概念について少し話題になっているようなので、再掲させていただきます。 <a href="https://t.co/n5bjZunG00">https://t.co/n5bjZunG00</a></p>
— 山口晃人 (@Akito_Yamaguchi) <a href="https://twitter.com/Akito_Yamaguchi/status/1851235713964015644?ref_src=twsrc%5Etfw">2024年10月29日</a></blockquote>
<p>
<script async="" src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
</p>
<p><a href="http://www.jcspt.jp/publications/nl/058_202407.pdf" target="_blank">http://www.jcspt.jp/publications/nl/058_202407.pdf</a></p>
<blockquote class="twitter-tweet" data-conversation="none" data-lang="ja">
<p dir="ltr" lang="ja">民主政について押さえておくべきことは、西洋の思想史においてこれが良き統治体制だと考えられたことはほとんど無かったということです。democracyとは直訳すれば多数者支配なのですが、賢明な人と馬鹿な人のどちらが多いですかということです。後者が支配する体制が良き統治体制である道理などない。</p>
— オッカム (@oxomckoe) <a href="https://twitter.com/oxomckoe/status/1851259161214063019?ref_src=twsrc%5Etfw">2024年10月29日</a></blockquote>
<p>
<script async="" src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
</p>
<p> </p>
