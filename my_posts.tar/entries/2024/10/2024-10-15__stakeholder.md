---
title: /stakeholder
published: 2024-10-15
updated: 2024-10-15T15:52:40+09:00
url: https://nisaki.hatenablog.jp/entry/2024/10/15/155240
entry-id: tag:blog.hatena.ne.jp,2013:blog-Nisaki-6801883189054638642-6802418398296285077
author: Nisaki
edited: 2024-10-15T15:52:40+09:00
draft: true---

<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Fblogs.lse.ac.uk%2Fimpactofsocialsciences%2F2024%2F05%2F07%2Fshould-we-stop-using-the-word-stakeholder-in-research%2F" title="Should we stop using the word ‘stakeholder’ in research?" class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://blogs.lse.ac.uk/impactofsocialsciences/2024/05/07/should-we-stop-using-the-word-stakeholder-in-research/">blogs.lse.ac.uk</a></cite></p>
