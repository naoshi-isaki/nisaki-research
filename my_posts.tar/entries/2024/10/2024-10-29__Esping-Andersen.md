---
title: /Esping-Andersen
published: 2024-10-29
updated: 2024-10-29T11:28:04+09:00
url: https://nisaki.hatenablog.jp/entry/2024/10/29/112804
entry-id: tag:blog.hatena.ne.jp,2013:blog-Nisaki-6801883189054638642-6802418398299811638
author: Nisaki
edited: 2024-10-29T11:28:04+09:00
draft: true
tags:
  - grancing_abstracts
---

<p>Parolin, Z., Schmitt, R. P., Esping-Andersen, G., &amp; Fallesen, P. (2023). The intergenerational persistence of poverty in high-income countries (No. 16194). IZA Discussion Papers.<br />https://doi.org/10.1038/s41562-024-02029-w</p>
<blockquote>
<p>子ども時代の貧困は、成人後の貧困の可能性を高める。 しかし、過去の研究では、貧困の世代間持続の強さとそれを支えるメカニズムにおける、国を超えた差異について、相反する説明がなされている。 ここで著者らは、米国、オーストラリア、デンマーク、ドイツ、英国における世代間貧困の差異を、行政および調査ベースのパネル・データを用いて調査している。 世代間貧困は、家族背景効果、媒介効果、税および移転保険効果、そして残余の貧困ペナルティに分解される。 貧困の世代間持続性は、米国では0.43（95％信頼区間（CI）＝0.40-0.46、P＜0.001）であるのに対し、英国では0.16（95％CI＝0.07-0.25、P＜0.001）、デンマークでは0.08（95％CI＝0.08-0.08、P＜0.001）である。 米国の不利は、家庭環境、媒介因子、近隣の影響、人種的・民族的差別によってもたらされるものではない。 その代わりに、米国は税と移転保険の効果が比較的弱く、残留貧困ペナルティがより深刻である。 もし米国が、同世代の国々の税と移転保険の効果を採用すれば、世代間の貧困の持続性は3分の1以上減少する可能性がある。</p>
</blockquote>
<p> </p>
