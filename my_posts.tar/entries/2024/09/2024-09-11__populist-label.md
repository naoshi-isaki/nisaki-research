---
title: /populist-label
published: 2024-09-11
updated: 2024-09-11T01:40:56+09:00
url: https://nisaki.hatenablog.jp/entry/2024/09/11/014056
entry-id: tag:blog.hatena.ne.jp,2013:blog-Nisaki-6801883189054638642-6802340630905393367
author: Nisaki
edited: 2024-09-11T01:40:56+09:00
draft: true---

<p>Malkopoulou, A., &amp; Moffitt, B. (2023). How not to respond to populism. Comparative European Politics, 21(6), 848-865.<br /><a href="https://doi.org/10.1057/s41295-023-00341-9" target="_blank">https://doi.org/10.1057/s41295-023-00341-9</a></p>
<p> </p>
<p> </p>
<p>Mondon, A. (2022). Populism, public opinion, and the mainstreaming of the far right: The ‘immigration issue’ and the construction of a reactionary ‘people’. Politics, 0(0). <a href="https://doi.org/10.1177/02633957221104726" target="_blank">https://doi.org/10.1177/02633957221104726</a></p>
<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Fwww.fairobserver.com%2Fregion%2Feurope%2Ffar-right-populist-parties-sweden-democrats-afd-europe-politics-news-analysis-19001%2F" title="Why We Shouldn't Call the Far Right an Unpopular Minority" class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://www.fairobserver.com/region/europe/far-right-populist-parties-sweden-democrats-afd-europe-politics-news-analysis-19001/">www.fairobserver.com</a></cite></p>
<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Ftheconversation.com%2Fthe-word-populism-is-a-gift-to-the-far-right-four-reasons-why-we-should-stop-using-it-224488" title="The word ‘populism’ is a gift to the far right – four reasons why we should stop using it" class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://theconversation.com/the-word-populism-is-a-gift-to-the-far-right-four-reasons-why-we-should-stop-using-it-224488">theconversation.com</a></cite></p>
<p> </p>
<p>Schwörer, J. (2021). Don't call me a populist! The meaning of populism for western European parties and politicians. Electoral Studies, 72, 102358.<br /><a href="https://doi.org/10.1016/j.electstud.2021.102358" target="_blank">https://doi.org/10.1016/j.electstud.2021.102358</a></p>
