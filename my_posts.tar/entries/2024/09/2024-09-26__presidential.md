---
title: /presidential
published: 2024-09-26
updated: 2024-09-27T13:14:11+09:00
url: https://nisaki.hatenablog.jp/entry/2024/09/27/131411
entry-id: tag:blog.hatena.ne.jp,2013:blog-Nisaki-6801883189054638642-6802340630909259584
author: Nisaki
edited: 2024-09-27T13:14:11+09:00
draft: true---

<p>Couto, L. (2024). Government formation in presidentialism: Disentangling the combined effects of pre-electoral coalitions and legislative polarization. Latin American Politics and Society, 1–20. doi:10.1017/lap.2024.30</p>
<p> </p>
<p> </p>
