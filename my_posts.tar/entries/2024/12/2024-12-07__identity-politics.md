---
title: /identity-politics
published: 2024-12-07
updated: 2024-12-07T08:31:51+09:00
url: https://nisaki.hatenablog.jp/entry/2024/12/07/083151
entry-id: tag:blog.hatena.ne.jp,2013:blog-Nisaki-6801883189054638642-6802418398309596413
author: Nisaki
edited: 2024-12-07T08:31:51+09:00
draft: true---

<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Fecon101.jp%2Fhow-steve-bannon-baited-the-american-left-into-overplaying-its-hand%2F" title="ジョセフ・ヒース「文化政治はなぜ生き残り続け、失敗し続けるのか」（2024年11月15日）" class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://econ101.jp/how-steve-bannon-baited-the-american-left-into-overplaying-its-hand/">econ101.jp</a></cite></p>
<p>---</p>
<blockquote class="bluesky-embed" data-bluesky-uri="at://did:plc:r7fnr5wagmon3oa3ae5zqf2k/app.bsky.feed.post/3lbunuos4es2r" data-bluesky-cid="bafyreibcapae52ijfn4qqx567n3motal6uf6peqd5qhc5jz3nl34dcqcf4">
<p lang="en">No, Kamala Harris did not lose because of her supposed embrace of “identity politics.” Just the reverse is true: Donald Trump won because of his very real embrace of identity politics. White identity politics. Thread, Part 1. 1/15</p>
— <a href="https://bsky.app/profile/did:plc:r7fnr5wagmon3oa3ae5zqf2k?ref_src=embed">David Neiwert (@davidneiwert.bsky.social)</a> <a href="https://bsky.app/profile/did:plc:r7fnr5wagmon3oa3ae5zqf2k/post/3lbunuos4es2r?ref_src=embed">2024-11-26T18:24:22.211Z</a></blockquote>
<p>
<script async="" src="https://embed.bsky.app/static/embed.js" charset="utf-8"></script>
<cite class="hatena-citation"><a href="https://bsky.app/profile/davidneiwert.bsky.social/post/3lbunuos4es2r">bsky.app</a></cite></p>
<p> </p>
