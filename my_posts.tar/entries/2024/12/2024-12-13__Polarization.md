---
title: /Polarization
published: 2024-12-13
updated: 2024-12-13T09:23:05+09:00
url: https://nisaki.hatenablog.jp/entry/2024/12/13/092305
entry-id: tag:blog.hatena.ne.jp,2013:blog-Nisaki-6801883189054638642-6802418398311207498
author: Nisaki
edited: 2024-12-13T09:23:05+09:00
draft: true---

<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Fedition.cnn.com%2F2024%2F12%2F09%2Fus%2Fpolarization-merriam-websters-word-of-the-year-is-2024-in-a-nutshell%2Findex.html" title="Polarization: Merriam-Webster’s word of year is 2024 in a nutshell | CNN" class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://edition.cnn.com/2024/12/09/us/polarization-merriam-websters-word-of-the-year-is-2024-in-a-nutshell/index.html">edition.cnn.com</a></cite></p>
<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Fapnews.com%2Farticle%2Fword-year-merriam-webster-2024-df39b7a3651f041ac6812155f1f67f45" title="‘Polarization’ is Merriam-Webster’s 2024 word of the year" class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://apnews.com/article/word-year-merriam-webster-2024-df39b7a3651f041ac6812155f1f67f45">apnews.com</a></cite></p>
<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Ftheconversation.com%2Fpolarization-brain-rot-and-brat-the-2024-words-of-the-year-point-to-the-power-perils-and-ephemeral-nature-of-digital-life-245251" title="Polarization, brain rot and brat – the 2024 words of the year point to the power, perils and ephemeral nature of digital life" class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://theconversation.com/polarization-brain-rot-and-brat-the-2024-words-of-the-year-point-to-the-power-perils-and-ephemeral-nature-of-digital-life-245251">theconversation.com</a></cite></p>
<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Flinktr.ee%2FEuropeanJournalPR" title="EJPR - Polarization 2024 | Linktree" class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://linktr.ee/EuropeanJournalPR">linktr.ee</a></cite></p>
