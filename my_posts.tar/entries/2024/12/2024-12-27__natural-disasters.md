---
title: /natural-disasters
published: 2024-12-27
updated: 2024-12-27T23:06:08+09:00
url: https://nisaki.hatenablog.jp/entry/2024/12/27/230608
entry-id: tag:blog.hatena.ne.jp,2013:blog-Nisaki-6801883189054638642-6802418398315162016
author: Nisaki
edited: 2024-12-27T23:06:08+09:00
draft: true---

<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Fcepr.org%2Fvoxeu%2Fcolumns%2Fexperiencing-natural-disasters-increases-partisan-disagreement-climate-change" title="Experiencing natural disasters increases partisan disagreement on climate change" class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://cepr.org/voxeu/columns/experiencing-natural-disasters-increases-partisan-disagreement-climate-change">cepr.org</a></cite></p>
