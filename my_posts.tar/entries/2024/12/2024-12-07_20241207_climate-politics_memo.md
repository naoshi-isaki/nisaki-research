---
title: 20241207/climate-politics/memo
published: 2024-12-07
updated: 2024-12-07T08:06:00+09:00
url: https://nisaki.hatenablog.jp/entry/2024/12/07/080600
entry-id: tag:blog.hatena.ne.jp,2013:blog-Nisaki-6801883189054638642-6802418398309592484
author: Nisaki
edited: 2024-12-07T08:06:00+09:00
tags:
  - political_party
---

<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Fpoliticscentre.nuffield.ox.ac.uk%2Fprogressive-politics-research-network%2Fresearch-briefs%2F" title="Research briefs - Nuffield Politics Research Centre" class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://politicscentre.nuffield.ox.ac.uk/progressive-politics-research-network/research-briefs/">politicscentre.nuffield.ox.ac.uk</a></cite></p>
<p>https://x.com/tabouchadi/status/1864957478976327874</p>
<p><iframe src="https://hatenablog-parts.com/embed?url=https%3A%2F%2Fwww.theguardian.com%2Fcommentisfree%2F2024%2Fdec%2F06%2F2024-greenlash-climate-breakdown-europeans-climate-action" title="Despite 2024’s ‘greenlash’, the fight against climate breakdown can still be won. Here’s how | Björn Bremer, Jane Gingrich and Hanna Schwander" class="embed-card embed-webcard" scrolling="no" frameborder="0" style="display: block; width: 100%; height: 155px; max-width: 500px; margin: 10px 0px;" loading="lazy"></iframe><cite class="hatena-citation"><a href="https://www.theguardian.com/commentisfree/2024/dec/06/2024-greenlash-climate-breakdown-europeans-climate-action">www.theguardian.com</a></cite></p>
