---
title: /to-read/memo
published: 2024-12-16
updated: 2024-12-16T21:51:22+09:00
url: https://nisaki.hatenablog.jp/entry/2024/12/16/215122
entry-id: tag:blog.hatena.ne.jp,2013:blog-Nisaki-6801883189054638642-6802418398312151955
author: Nisaki
edited: 2024-12-16T21:51:22+09:00
draft: true---

<p>Streeck, W. (2024). A matter of state: The politics of German anti-anti-Semitism. European Journal of Social Theory, 0(0).<br />https://doi.org/10.1177/13684310241300838</p>
<p>Salas‐Díaz, R., &amp; Young, K. L. (2024). Where did the global elite go to school? Hierarchy, Harvard, home and hegemony. Global Networks, e12509. https://doi.org/10.1111/glob.12509</p>
<p>Atikcan, E. Ö. (2018). Agenda control in EU referendum campaigns: The power of the anti‐EU side. European Journal of Political Research, 57(1), 93-115.<br />https://doi.org/10.1111/1475-6765.12217</p>
<p>Häusermann, S., Palier, B., &amp; Paris, S. Social Investment–A (Mis) leading Paradigm? Why We Need to Distinguish Different Types of Social Investments.<br />https://www.researchgate.net/publication/386869833_Social_Investment_-A_Misleading_Paradigm_Why_We_Need_to_Distinguish_Different_Types_of_Social_Investments</p>
<p>Martigny, V., &amp; Peters, B. G. (2024). All the President's Men: Comparing the Secretary General of the French Presidency and the US Chief of Staff in an Era of Presidentialization. Government and Opposition, 1-19.<br />https://doi.org/10.1017/gov.2024.16</p>
<p> </p>
<p> </p>
